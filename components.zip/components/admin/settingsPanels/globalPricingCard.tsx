'use client';

import { useEffect, useMemo, useState } from 'react';
import { db } from '@/lib/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';

type ServiceFees = Record<string, number>;
type BoostPrices = { floatingPerHour?: number; bannerPerHour?: number };
type GlobalSettingsDoc = { serviceFees?: ServiceFees; boostPrices?: BoostPrices };

const PRESET_DURATIONS = [12, 24, 36, 48, 72, 96, 120, 144, 168, 192, 216, 240, 264, 288, 312, 336];

export default function GlobalPricingCard() {
    const [loading, setLoading] = useState(true);
    const [serviceFees, setServiceFees] = useState<ServiceFees>({});
    const [selectedDuration, setSelectedDuration] = useState<string>('24');
    const [selectedFee, setSelectedFee] = useState<string>('');
    const [floatingPerHour, setFloatingPerHour] = useState<string>('20');
    const [bannerPerHour, setBannerPerHour] = useState<string>('10');

    useEffect(() => {
        (async () => {
            const ref = doc(db, 'settings', 'global');
            const snap = await getDoc(ref);
            if (snap.exists()) {
                const data = snap.data() as GlobalSettingsDoc;
                setServiceFees({ ...(data.serviceFees || {}) });
                setFloatingPerHour(String(data.boostPrices?.floatingPerHour ?? 20));
                setBannerPerHour(String(data.boostPrices?.bannerPerHour ?? 10));
            } else {
                // Defaults – tomt kort som du fyller själv
                setServiceFees({ 12: 3, 24: 4, 36: 5, 48: 6, 72: 7, 96: 8, 120: 9, 144: 10 } as any);
            }
            setLoading(false);
        })();
    }, []);

    const sortedDurations = useMemo(
        () => Object.keys(serviceFees).map(Number).sort((a, b) => a - b),
        [serviceFees]
    );

    const addOrUpdateFee = () => {
        const dur = parseInt(selectedDuration, 10);
        const fee = Number(selectedFee);
        if (!Number.isFinite(dur) || dur <= 0) return;
        if (!Number.isFinite(fee) || fee < 0) return;
        setServiceFees(prev => ({ ...prev, [String(dur)]: fee }));
        setSelectedFee('');
    };

    const removeDuration = (h: number) => {
        const copy = { ...serviceFees };
        delete copy[String(h)];
        setServiceFees(copy);
    };

    const saveAll = async () => {
        const ref = doc(db, 'settings', 'global');
        // städa numeriska värden
        const cleaned: ServiceFees = {};
        for (const [k, v] of Object.entries(serviceFees)) {
            const dk = String(parseInt(k, 10));
            const dv = Number(v);
            if (Number.isFinite(Number(dk)) && Number.isFinite(dv)) cleaned[dk] = dv;
        }
        await setDoc(
            ref,
            {
                serviceFees: cleaned,
                boostPrices: {
                    floatingPerHour: Number(floatingPerHour) || 0,
                    bannerPerHour: Number(bannerPerHour) || 0,
                },
            },
            { merge: true }
        );
        // Du kan ersätta alert med din toast-komponent
        alert('Inställningar sparade!');
    };

    return (
        <div className="border rounded-xl p-5 bg-white shadow-sm">
            <div className="mb-4">
                <h3 className="text-xl font-semibold">Globala priser & avgifter</h3>
                <p className="text-sm text-muted-foreground">
                    Ändringar uppdaterar direkt CreateDealForm, Boost-dialogen och checkoutflödet.
                </p>
            </div>

            {loading ? (
                <p className="text-sm text-muted-foreground">Laddar…</p>
            ) : (
                <Accordion type="multiple" className="space-y-3">
                    {/* Serviceavgifter */}
                    <AccordionItem value="fees" className="border rounded-lg px-3">
                        <AccordionTrigger className="py-3">Serviceavgifter (%) per varaktighet</AccordionTrigger>
                        <AccordionContent>
                            <div className="grid gap-3 md:grid-cols-2">
                                <div className="space-y-2">
                                    <Label>Varaktighet (dropdown)</Label>
                                    <Select value={selectedDuration} onValueChange={setSelectedDuration}>
                                        <SelectTrigger><SelectValue placeholder="Välj varaktighet" /></SelectTrigger>
                                        <SelectContent>
                                            {PRESET_DURATIONS.map((h) => (
                                                <SelectItem key={h} value={String(h)}>
                                                    {h <= 48 ? `${h} timmar` : `${h / 24} dagar`}
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2">
                                    <Label>Avgift (%)</Label>
                                    <Input
                                        type="number"
                                        placeholder="t.ex. 10"
                                        value={selectedFee}
                                        onChange={(e) => setSelectedFee(e.target.value)}
                                    />
                                </div>
                            </div>

                            <div className="mt-3">
                                <Button variant="secondary" onClick={addOrUpdateFee}>Lägg till / uppdatera</Button>
                            </div>

                            <div className="mt-5">
                                <div className="mb-2 text-sm font-medium">Aktiva nivåer</div>
                                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
                                    {sortedDurations.length === 0 && (
                                        <p className="text-sm text-muted-foreground">Inga nivåer ännu.</p>
                                    )}
                                    {sortedDurations.map((h) => (
                                        <div key={h} className="flex items-center justify-between rounded-md border p-2">
                                            <div className="flex items-center gap-2">
                                                <Badge variant="secondary">{h <= 48 ? `${h}h` : `${h / 24}d`}</Badge>
                                                <span className="text-sm">{serviceFees[String(h)]}%</span>
                                            </div>
                                            <Button variant="ghost" size="sm" onClick={() => removeDuration(h)}>
                                                Ta bort
                                            </Button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </AccordionContent>
                    </AccordionItem>

                    {/* Boostpriser */}
                    <AccordionItem value="boost" className="border rounded-lg px-3">
                        <AccordionTrigger className="py-3">Boostpriser (SEK / timme)</AccordionTrigger>
                        <AccordionContent>
                            <div className="grid md:grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label>Floating – SEK/timme</Label>
                                    <Input
                                        type="number"
                                        min={0}
                                        value={floatingPerHour}
                                        onChange={(e) => setFloatingPerHour(e.target.value)}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Banner – SEK/timme</Label>
                                    <Input
                                        type="number"
                                        min={0}
                                        value={bannerPerHour}
                                        onChange={(e) => setBannerPerHour(e.target.value)}
                                    />
                                </div>
                            </div>
                        </AccordionContent>
                    </AccordionItem>
                </Accordion>
            )}

            <div className="mt-5">
                <Button onClick={saveAll}>Spara ändringar</Button>
            </div>
        </div>
    );
}
